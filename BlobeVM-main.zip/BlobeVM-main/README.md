# BlobeVM (Modified DesktopOnCodespaces)
### Installation
First start a new blank codespace by going to https://github.com/codespaces/ and choosing the "Blank" template.
Then copy and paste this command in your codespace terminal and hit enter.
```
curl -O https://raw.githubusercontent.com/Blobby-Boi/BlobeVM/main/install.sh
chmod +x install.sh
./install.sh
```
