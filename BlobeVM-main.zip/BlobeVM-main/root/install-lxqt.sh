#!/bin/bash
setterm blank 0
setterm powerdown 0
/usr/bin/startlxqt > /dev/null 2>&1