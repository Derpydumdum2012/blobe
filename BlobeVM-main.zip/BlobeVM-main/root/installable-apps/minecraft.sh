sudo apt update
sudo apt install default-jre
wget https://launcher.mojang.com/download/Minecraft.deb
sudo dpkg -i Minecraft.deb
