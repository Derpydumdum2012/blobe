apt update
apt install -y synaptic