apt update
apt install -y libreoffice-writer libreoffice-math libreoffice-impress libreoffice-base