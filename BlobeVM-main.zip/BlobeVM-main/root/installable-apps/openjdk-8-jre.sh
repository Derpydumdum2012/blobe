apt update
apt install -y openjdk-8-jre